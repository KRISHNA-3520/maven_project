package com.practice.practice;

public class test_encapsulation {

	public static void main(String[] args) {
	
		student_encapsulation s=new student_encapsulation();
		
		s.setName("Krishna");
		System.out.println("Name :"+s.getName());
	}

}
