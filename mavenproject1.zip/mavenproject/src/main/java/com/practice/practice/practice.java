package com.practice.practice;

import java.util.Scanner;

public class practice {

	public static void main(String[] args) {
		int[] a = {5, 8, 6, 3, 4};

		System.out.println("Array before sorting");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}

		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				int toplace=i;

				for(int j=i+1;j<a.length;j++)
				{
					if(a[j]%2!=0 && a[i] > a[j])
					{
						toplace=j;
					}
				}
					int temp=a[toplace];
					a[toplace]=a[i];
					a[i] = temp;
			}
		}
		System.out.println();
		System.out.println("Array after sorting");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}
